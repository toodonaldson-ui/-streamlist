# StreamList ScreenPal Walkthrough

Aim for 2–3 minutes, including time to show the screen and demonstrate each action. Have StreamList open in a desktop browser and VS Code open to `src/App.jsx` and `src/pages/StreamList.jsx` before recording. Open the browser developer console and clear it. Capture the desktop or the windows you need with ScreenPal and enable your microphone.

## 0:00–0:25 — Introduce StreamList

Show the homepage.

“Hi, I’m Stephon Donaldson. This is StreamList, a React application for EZTechMovie. The idea is to give users one place to keep track of movies and shows they want to watch. For this first week, I focused on getting the navigation and the title submission working.”

## 0:25–1:10 — Demonstrate the form

Type `Interstellar`, click **Submit title**, and point to the console output. Then type `The Bear` and press Enter.

“On the homepage, I can enter a title and submit it. I’ll use Interstellar first. When I click Submit title, the title appears in the browser console and the field clears. I can also submit by pressing Enter. Here’s a second example with The Bear. The console is the output for Week 1.”

## 1:10–1:45 — Walk through navigation

Click **Movies**, **Cart**, **About**, and then **StreamList**.

“React Router lets me switch between these pages without reloading the site. The active menu item shows which page I’m on. Movies and Cart are set up for Week 4, and About is set up for Week 5. For now, each has a heading and no data. I can use the StreamList link to return to the homepage.”

## 1:45–2:20 — Explain the code and styling

Show the routes in `src/App.jsx` and the submit handler in `src/pages/StreamList.jsx`.

“I set up the project with React and Vite, then added the routes and put the shared navigation in its own component. The title field uses React state to track what the user types. On submit, the handler trims extra spaces and logs the title. I styled the app with CSS and used Lucide icons in the menu. The layout also adjusts to smaller screens.”

## Submission checklist

- Upload the extracted project contents to a GitHub repository. Skip `node_modules` and `dist`. Share the repository URL with your instructor and make sure they have access.
- Record the walkthrough with [ScreenPal](https://screenpal.com/channel/tutorials-record-your-screen). Confirm that the video runs 2–5 minutes and that the console output is readable.
- In Canvas, use **Submit Assignment** for Part 1. Include the recording and the GitHub repository URL. Review the separate Part 2 instructions before submitting that portion.
