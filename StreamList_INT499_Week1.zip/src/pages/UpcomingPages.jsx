export function Movies() {
  return <h1 className="page-title">Movies</h1>;
}

export function Cart() {
  return <h1 className="page-title">Cart</h1>;
}

export function About() {
  return <h1 className="page-title">About</h1>;
}
