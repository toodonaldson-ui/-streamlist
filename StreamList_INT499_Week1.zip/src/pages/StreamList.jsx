import { Check, Clapperboard, Plus } from 'lucide-react';
import { useState } from 'react';

export default function StreamList() {
  const [title, setTitle] = useState('');
  const [status, setStatus] = useState('');

  function handleSubmit(event) {
    event.preventDefault();
    const submittedTitle = title.trim();

    if (!submittedTitle) {
      setStatus('Enter a movie or show title.');
      return;
    }

    console.log('StreamList submission:', submittedTitle);
    setTitle('');
    setStatus('Title sent to the browser console.');
  }

  return (
    <>
      <section className="hero" aria-labelledby="home-title">
        <div className="hero-copy">
          <h1 id="home-title">Stream<span>List</span></h1>
          <p>What are you watching next?</p>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="art-orbit" />
          <div className="film-strip"><div className="film-frames" /></div>
          <div className="art-disc"><Clapperboard strokeWidth={1.5} /></div>
        </div>
      </section>

      <section className="entry-panel" aria-labelledby="entry-title">
        <h2 id="entry-title">Add a title</h2>
        <form onSubmit={handleSubmit}>
          <label htmlFor="stream-title">Movie or show title</label>
          <div className="form-row">
            <input
              id="stream-title"
              name="title"
              placeholder="e.g. Interstellar"
              value={title}
              onChange={(event) => {
                setTitle(event.target.value);
                setStatus('');
              }}
              required
            />
            <button type="submit"><Plus size={20} aria-hidden="true" /> Submit title</button>
          </div>
        </form>
        <p className="submission-status" role="status">
          {status && (
            <>
              {status.startsWith('Title sent') && <Check size={16} aria-hidden="true" />}
              {status}
            </>
          )}
        </p>
      </section>
    </>
  );
}
