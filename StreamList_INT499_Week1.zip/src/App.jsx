import { Navigate, Route, Routes } from 'react-router-dom';
import Navigation from './components/Navigation.jsx';
import StreamList from './pages/StreamList.jsx';
import { About, Cart, Movies } from './pages/UpcomingPages.jsx';

export default function App() {
  return (
    <>
      <Navigation />
      <main className="shell">
        <Routes>
          <Route path="/" element={<StreamList />} />
          <Route path="/movies" element={<Movies />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/about" element={<About />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </>
  );
}
