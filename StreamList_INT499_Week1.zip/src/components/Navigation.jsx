import { Clapperboard, Film, Info, ListVideo, ShoppingCart } from 'lucide-react';
import { Link, NavLink } from 'react-router-dom';

const links = [
  { label: 'StreamList', path: '/', icon: ListVideo },
  { label: 'Movies', path: '/movies', icon: Film },
  { label: 'Cart', path: '/cart', icon: ShoppingCart },
  { label: 'About', path: '/about', icon: Info },
];

export default function Navigation() {
  return (
    <header className="site-header">
      <div className="header-content shell">
        <Link className="brand" to="/" aria-label="EZTechMovie home">
          <span className="brand-icon"><Clapperboard size={21} aria-hidden="true" /></span>
          EZTechMovie
        </Link>
        <nav className="navigation" aria-label="Main navigation">
          {links.map(({ label, path, icon: Icon }) => (
            <NavLink key={path} to={path} end={path === '/'}>
              <Icon size={17} aria-hidden="true" />
              {label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
}
