# StreamList

INT499 Week 1 Assignment 1, Part 1. A React app for EZTechMovie.

## Run the app

Use Node.js 22.12 or newer (or Node.js 20.19+ on the 20.x release line). Open this folder in Visual Studio Code and use its terminal.

```sh
npm ci
npm run dev
```

Open the localhost URL Vite prints. Use `npm run build` to verify the production build.

## Week 1 behavior

- **StreamList** (`/`) accepts a movie or show title. Submitting a nonblank title logs it in the browser's developer console and clears the input. Entries are console-only at this stage.
- **Movies** (`/movies`) and **Cart** (`/cart`) are empty apart from their headings. Their features are scheduled for Week 4.
- **About** (`/about`) is empty apart from its heading. Its content is scheduled for Week 5.

React Router switches between pages without reloading the application. The navigation links indicate the current page. The home page uses a controlled form and responsive CSS. Its icons are from [Lucide](https://lucide.dev/).

## ScreenPal walkthrough and GitHub submission

See [SCREENPAL_WALKTHROUGH.md](SCREENPAL_WALKTHROUGH.md) for the demo sequence, narration and submission checklist.
